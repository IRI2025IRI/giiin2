// このコンポーネントは新しいURL認証システムでは不要になりました
// 新規登録はLoginModalで統合されています

export function SignUpForm() {
  return null;
}

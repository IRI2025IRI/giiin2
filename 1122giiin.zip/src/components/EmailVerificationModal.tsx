// このコンポーネントは新しいURL認証システムでは不要になりました
// メール認証はURL方式に変更されています

export function EmailVerificationModal() {
  return null;
}
